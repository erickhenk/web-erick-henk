



/*menu*/
const headerBtn = document.querySelector('.headerBtn');
const nav    = document.querySelector('.nav');


headerBtn.addEventListener('click', () =>{
    nav.classList.toggle("activo");
});





  /*slides*/

  // Esperar a que la página esté completamente cargada
  let currentIndex = 0;
  const slides = document.querySelectorAll('.slide');
  const totalSlides = slides.length;

  function changeSlide(direction) {
      currentIndex = (currentIndex + direction + totalSlides) % totalSlides;
      document.querySelector('.slides').style.transform = 'translateX(' + (-currentIndex * 100) + '%)';
  }

  window.onload = function() {
      // Añadir eventos de clic a los botones de navegación
      document.querySelector('.prev').addEventListener('click', () => changeSlide(-1));
      document.querySelector('.next').addEventListener('click', () => changeSlide(1));

      // Cambio automático de diapositiva cada 3 segundos
      setInterval(() => {
          changeSlide(1);
      }, 8000);
  };

  /*tabs*/

function openServicio(evt, tipoServicio) {
  let i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(tipoServicio).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
