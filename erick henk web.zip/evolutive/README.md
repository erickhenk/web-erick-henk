# Nombre del Proyecto
Erickhenk.com

Este es un sitio web personal desarrollado con HTML, CSS y JavaScript que muestra una descripción de lo que hago laboralmente y ofrezco como servicios digitales a la comunidad.

## Tabla de Contenidos

- [Descripción](#descripción)
- [Estructura del Proyecto](#estructura-del-proyecto)
- [Instalación](#instalación)
- [Uso](#uso)
- [Contribución](#contribución)
- [Licencia](#licencia)

## Descripción

Este proyecto es una web básica creada con **HTML**, **CSS** y **JavaScript**. Se diseñó para demostrar una estructura de sitio web con un diseño responsivo y algunas funciones interactivas simples. Ideal como punto de partida para proyectos web o como una plantilla base para experimentar con nuevas características de frontend.



# Proyecto Web Erick Henk

> Un sitio web personal construido con HTML, CSS y JavaScript.

Este proyecto es un ejemplo de sitio web simple con una estructura de página HTML, un diseño responsivo en CSS, y funcionalidades básicas de JavaScript. Fue desarrollado con el propósito de presentación de proyecto final para máster en CEI Madrid.

## Tabla de Contenidos

- [Descripción](#descripción)
- [Características](#características)
- [Estructura del Proyecto](#estructura-del-proyecto)
- [Instalación](#instalación)
- [Uso](#uso)
- [Tecnologías Utilizadas](#tecnologías-utilizadas)
- [Contribución](#contribución)
- [Licencia](#licencia)

## Descripción

Este proyecto es un sitio web personal diseñado para demostrar el uso de HTML, CSS y JavaScript, con contenido que muestra una descripción de lo que hago laboralmente y ofrezco como servicios digitales a la comunidad. Incluye ejemplos de diseño responsivo, animaciones y efectos simples de JavaScript, como un carrusel de imágenes o un menú de navegación interactivo.



## Características

- **Diseño Responsivo**: Adaptable a diferentes tamaños de pantalla.
- **Interactividad en JavaScript**: Funciones simples, como un carrusel de imágenes o botones interactivos.
- **Fácil de Personalizar**: Se puede usar como una plantilla base para proyectos más complejos.

## Estructura del Proyecto
Home.html
Acerca.html
Evoluptive.html
Servicios.html
Web.html
Videos.html
Contacto.html
css/style.css
js/index.js
img/



## Uso
Navegación: La página principal (index.html) contiene la estructura HTML y es completamente navegable con enlaces internos.
Funcionalidades JavaScript: Experimenta con las interacciones de la página, como el carrusel de imágenes o el botón de menú en dispositivos móviles.
Personalización: Modifica los archivos CSS y JavaScript para adaptar el sitio a tus necesidades.

## Tecnologías usadas
HTML5: Estructura y contenido de la página.
CSS3: Diseño y estilos responsivos.
JavaScript: Funcionalidades interactivas y dinámicas.

